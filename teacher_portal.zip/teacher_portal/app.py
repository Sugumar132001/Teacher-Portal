from flask import Flask, render_template, request, redirect, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Sugumar%409505@localhost:3306/teacher_portals'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# -----------------------------
# Models
# -----------------------------

class Teachers(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

class Students(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    subject = db.Column(db.String(100), nullable=False)
    marks = db.Column(db.Integer, nullable=False)


# -----------------------------
# Routes
# -----------------------------

@app.route('/')
def login():
    return render_template('login.html')


@app.route('/login', methods=['POST'])
def do_login():
    username = request.form['username']
    password = request.form['password']

    teacher = Teachers.query.filter_by(username=username, password=password).first()
    if teacher:
        return redirect('/home')
    else:
        return render_template('login.html', error="Invalid Credentials")


@app.route('/home')
def home():
    students = Students.query.all()
    return render_template('home.html', students=students)


@app.route('/add_student', methods=['POST'])
def add_student():
    name = request.form['name']
    subject = request.form['subject']
    marks = int(request.form['marks'])

    existing = Students.query.filter_by(name=name, subject=subject).first()
    if existing:
        existing.marks += marks
    else:
        new_student = Students(name=name, subject=subject, marks=marks)
        db.session.add(new_student)

    db.session.commit()
    return redirect('/home')


@app.route('/update_student', methods=['POST'])
def update_student():
    student_id = request.form['id']
    name = request.form['name']
    subject = request.form['subject']
    marks = int(request.form['marks'])

    student = Students.query.get(student_id)
    if student:
        student.name = name
        student.subject = subject
        student.marks = marks
        db.session.commit()
        return jsonify(success=True)
    else:
        return jsonify(success=False, error="Student not found")


@app.route('/delete_student', methods=['POST'])
def delete_student():
    student_id = request.form['id']
    student = Students.query.get(student_id)
    if student:
        db.session.delete(student)
        db.session.commit()
        return jsonify(success=True)
    else:
        return jsonify(success=False, error="Student not found")


# -----------------------------
# Run the App
# -----------------------------
if __name__ == '__main__':
    app.run(debug=True)
